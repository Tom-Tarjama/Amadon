# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, redirect

# Create your views here.

def index(request):
	return render(request, "Amadon_app/index.html")

def process(request):
		
	context = {}
	context['item'] = int(request.POST['product_id'])
	context['quantity'] = float(request.POST['quantity'])

	if context['item'] == 1:
		context['price'] = 19.99
	elif context['item'] == 2:
		context['price'] = 29.99
	elif context['item'] == 3:
		context['price'] = 4.99
	elif context['item'] == 4:
		context['price'] = 49.99

	

	# print context['price']
	# print type(context['price'])

	context['purchase_total'] = context['quantity']*context['price']

	print context

	print "THIS", context['purchase_total']


	if 'total' not in request.session:
		request.session['total'] = 0.0

	request.session['total']+=context['purchase_total']

	if 'counter' not in request.session:
		request.session['counter'] = 0

	request.session['counter']+=int(context['quantity'])

	if 'price' not in request.session:
		request.session['price'] = 0.0

	request.session['price'] = context['purchase_total']

	return redirect ("/result")

def result(request):

	print "COUNT", request.session['counter']

	print "TOTAL SPENT", request.session['total']

	print "SPENT THIS PURCHASE", request.session['price'] 

	return render(request, "Amadon_app/result.html")

def goback(request):

	return redirect("/")

def reset(request):

	request.session['total'] =0.0

	request.session['counter'] = 0

	request.session['price'] = 0.0

	return redirect("/")

